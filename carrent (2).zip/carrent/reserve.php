<?php
session_start();
include "connect.php";
include "Includes/templates/header.php";
include "Includes/templates/navbar.php";
include "Includes/functions/functions.php";

if (isset($_POST['reserve_car']) && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $_SESSION['pickup_location'] = test_input($_POST['pickup_location']);
    $_SESSION['return_location'] = test_input($_POST['return_location']);
    $_SESSION['pickup_date'] = test_input($_POST['pickup_date']);
    $_SESSION['return_date'] = test_input($_POST['return_date']);
}
?>

<!-- BANNER SECTION -->
<div class="reserve-banner-section">
    <h2>Reserve your car</h2>
</div>

<!-- CAR RESERVATION SECTION -->
<section class="car_reservation_section">
    <div class="container">
        <?php
        if (isset($_POST['submit_reservation']) && $_SERVER['REQUEST_METHOD'] === 'POST') {
            $selected_car = test_input($_POST['selected_car']);
            $full_name = test_input($_POST['full_name']);
            $client_email = test_input($_POST['client_email']);
            $client_phonenumber = test_input($_POST['client_phonenumber']);
            
            if (empty($full_name) || empty($client_email) || empty($client_phonenumber) || empty($selected_car)) {
                echo "<div class='alert alert-danger'>Please fill all required fields.</div>";
            } else {
                try {
                    $pickup_location = $_SESSION['pickup_location'];
                    $return_location = $_SESSION['return_location'];
                    $pickup_date = $_SESSION['pickup_date'];
                    $return_date = $_SESSION['return_date'];

                    // Begin Transaction
                    $con->beginTransaction();

                    // Insert Client Details
                    $stmtClient = $con->prepare("INSERT INTO clients (full_name, client_email, client_phone) VALUES (?, ?, ?)");
                    $stmtClient->execute([$full_name, $client_email, $client_phonenumber]);

                    // Get Last Inserted Client ID
                    $client_id = $con->lastInsertId();

                    // Insert Reservation Details
                    $stmt_appointment = $con->prepare("INSERT INTO reservations (client_id, car_id, pickup_date, return_date, pickup_location, return_location) 
                                                       VALUES (?, ?, ?, ?, ?, ?)");
                    $stmt_appointment->execute([$client_id, $selected_car, $pickup_date, $return_date, $pickup_location, $return_location]);

                    // Commit Transaction
                    $con->commit();

                    echo "<div class='alert alert-success'>Great! Your reservation has been created successfully.</div>";
                } catch (Exception $e) {
                    $con->rollBack();
                    echo "<div class='alert alert-danger'>Error: " . $e->getMessage() . "</div>";
                }
            }
        } elseif (isset($_SESSION['pickup_date']) && isset($_SESSION['return_date'])) {
            $pickup_date = $_SESSION['pickup_date'];
            $return_date = $_SESSION['return_date'];

            // Fetch Available Cars
            $stmt = $con->prepare("SELECT * FROM cars 
                                    JOIN car_brands ON cars.brand_id = car_brands.brand_id 
                                    JOIN car_types ON cars.type_id = car_types.type_id 
                                    WHERE cars.id NOT IN (
                                        SELECT car_id FROM reservations 
                                        WHERE (? BETWEEN pickup_date AND return_date OR ? BETWEEN pickup_date AND return_date) 
                                        AND canceled = 0
                                    )");
            $stmt->execute([$pickup_date, $return_date]);
            $available_cars = $stmt->fetchAll();
        ?>
            <!-- Reservation Form -->
            <form action="reserve.php" method="POST" id="reservation_second_form" v-on:submit="checkForm">
                <div class="row" style="margin-bottom: 20px;">
                    <div class="col-md-3 reservation_cards">
                        <p><i class="fas fa-calendar-alt"></i> <span>Pickup Date:</span> <?php echo $_SESSION['pickup_date']; ?></p>
                    </div>
                    <div class="col-md-3 reservation_cards">
                        <p><i class="fas fa-calendar-alt"></i> <span>Return Date:</span> <?php echo $_SESSION['return_date']; ?></p>
                    </div>
                    <div class="col-md-3 reservation_cards">
                        <p><i class="fas fa-map-marked-alt"></i> <span>Pickup Location:</span> <?php echo $_SESSION['pickup_location']; ?></p>
                    </div>
                    <div class="col-md-3 reservation_cards">
                        <p><i class="fas fa-map-marked-alt"></i> <span>Return Location:</span> <?php echo $_SESSION['return_location']; ?></p>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-7">
                        <div class="btn-group-toggle" data-toggle="buttons">
                            <div class="items_tab">
                                <?php foreach ($available_cars as $car) { ?>
                                    <div class="itemListElement">
                                        <div class="item_details">
                                            <div><?php echo $car['car_name']; ?></div>
                                            <div class="item_select_part">
                                                <label class="item_label btn btn-secondary">
                                                    <input type="radio" class="radio_car_select" name="selected_car" value="<?php echo $car['id']; ?>"> Select
                                                </label>
                                            </div>
                                        </div>
                                    </div>
                                <?php } ?>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-5">
                        <div class="client_details">
                            <div class="form-group">
                                <label for="full_name">Full Name</label>
                                <input type="text" class="form-control" placeholder="John Doe" name="full_name">
                            </div>
                            <div class="form-group">
                                <label for="client_email">E-mail</label>
                                <input type="email" class="form-control" placeholder="abc@mail.xyz" name="client_email">
                            </div>
                            <div class="form-group">
                                <label for="client_phonenumber">Phone Number</label>
                                <input type="text" class="form-control" placeholder="0123456789" name="client_phonenumber">
                            </div>
                            <button type="submit" class="btn sbmt-bttn" name="submit_reservation">Book Instantly</button>
                        </div>
                    </div>
                </div>
            </form>
        <?php
        } else {
        ?>
            <div style="max-width:500px; margin:auto;">
                <div class="alert alert-warning">Please select pickup and return dates first.</div>
                <button class="btn btn-info" style="display:block;margin:auto">
                    <a href="./#reserve" style="color:white">Homepage</a>
                </button>
            </div>
        <?php
        }
        ?>
    </div>
</section>

<?php include "Includes/templates/footer.php"; ?>

